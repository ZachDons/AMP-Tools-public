#include "MyConfigurationSpace.h"
#include "MyLinkManipulator2D.h"
using namespace amp;

MyConfigurationSpace::MyConfigurationSpace(std::size_t x0_cells, std::size_t x1_cells, double x0_min, double x0_max, double x1_min, double x1_max)
    : GridCSpace2D(x0_cells, x1_cells, x0_min, x0_max, x1_min, x1_max) {}

// bool MyConfigurationSpace::check_collision(int i_x0, int i_x1)
// {
//     // Initialize variables
//     int num_obs = obstacles.size();
//     vector<double> links = robot.getLinkLengths();
//     int num_links = links.size();
//     // Loop through each obstacle
//     for (int i_obs = 0; i_obs < num_obs; i_obs++)
//     {
//         vector<Vector2d> obs_vertices = obstacles[i_obs].verticesCCW();
//         int num_obs_vertices = obs_vertices.size();
//         cout << "Obs " << i_obs << "with " << num_obs_vertices << " vertices" << std::endl;

//         for (int i_vrtx = 0; i_vrtx < num_obs_vertices; i_vrtx++)
//         {
//         }
//     }
//     // operator(i,j);
//     return false;
// };

void MyConfigurationSpace::compute_Cspace(vector<Obstacle2D> obstacles, MyLinkManipulator2D robot)
{
    // Define member variables
    all_obstacles = obstacles;
    my_robot = robot;
    // Initialize grid size
    std::pair<int, int> grid_size = size();
    int x0_size = grid_size.first;
    int x1_size = grid_size.second;
    double x0_step = 2 * M_PI / x0_size;
    double x1_step = 2 * M_PI / x1_size;
    int ii = 0;
    int jj = 0;
    bool collision_at_state;
    for (int i_x0 = 0; i_x0 < x0_size; i_x0++)
    {

        for (int i_x1 = 0; i_x1 < x1_size; i_x1++)
        {
            double x0 = i_x0 * x0_step;
            double x1 = i_x1 * x1_step;
            cout << std::endl;
            cout << "Test x0: " << x0 << " x1: " << x1 << std::endl;
            collision_at_state = inCollision(x0, x1);
            cout << "Is there a collision? " << collision_at_state << std::endl;

            //ii = i_x0; jj = i_x1;
            if (collision_at_state)
            // if (i_x0 == i_x1)
            {
                // cout << "this operator triggered at: i_x0 = "<<i_x0 << " | i_x1 = " << i_x1 << std::endl;
                operator()(i_x0, i_x1) = 1;
                
            }
            
        }
    }
}

bool MyConfigurationSpace::inCollision(double x0, double x1) const
{
    // Initialize params of member variables
    int num_obs = all_obstacles.size();
    vector<double> links = my_robot.getLinkLengths();
    int num_links = links.size();

    // collision flag (true = collided)
    bool collision_occurred = false;
    bool lines_intersect = false;

    // Loop through each link
    for (int i_link = 0; i_link < num_links; i_link++)
    {
        // Get vertices of i_link and i_link+1
        Vector2d link_vrtx_1 = my_robot.getJointLocation({x0, x1}, i_link);
        Vector2d link_vrtx_2 = my_robot.getJointLocation({x0, x1}, i_link + 1);
        double link_vrtx_1x = link_vrtx_1.x();
        double link_vrtx_1y = link_vrtx_1.y();
        double link_vrtx_2x = link_vrtx_2.x();
        double link_vrtx_2y = link_vrtx_2.y();
        // cout << "Link iteration (i_link) =  " << i_link << ":" << std::endl;
        cout << "Link vertex i_link =  " << link_vrtx_1 << std::endl;
        cout << "Link vertex i_link+1 =  " << link_vrtx_2 << std::endl;

        // Loop through each obstacle
        for (int i_obs = 0; i_obs < num_obs; i_obs++)
        {
            // Initialize obstacle params
            vector<Vector2d> obs_vertices = all_obstacles[i_obs].verticesCCW();
            int num_obs_vertices = obs_vertices.size();
            cout << "Obs " << i_obs << " with " << num_obs_vertices << " vertices" << std::endl;
            //  Loop through every vertex from each obstacle
            for (int i_vrtx = 0; i_vrtx < num_obs_vertices; i_vrtx++)
            {
                // wrap vertices
                int i_vrtx_p1 = i_vrtx + 1;
                if (i_vrtx == (num_obs_vertices - 1))
                {
                    int i_vrtx_p1 = 0;
                }

                // Collision check
                double obs_vrtx_1x = obs_vertices[i_vrtx].x();
                double obs_vrtx_1y = obs_vertices[i_vrtx].y();
                double obs_vrtx_2x = obs_vertices[i_vrtx_p1].x();
                double obs_vrtx_2y = obs_vertices[i_vrtx_p1].y();

                // Calculate the direction vectors of the two line segments
                // obstacle
                double dx1 = obs_vrtx_2x - obs_vrtx_1x;
                double dy1 = obs_vrtx_2y - obs_vrtx_1y;
                // link
                double dx2 = link_vrtx_2x - link_vrtx_1x;
                double dy2 = link_vrtx_2y - link_vrtx_1y;
                // Parallel line check (det ~= 0)
                double determinant = dx1 * dy2 - dx2 * dy1;
                if (std::abs(determinant) < 1e-6)
                {
                    break;
                }
                // Line equation parameters
                double t1 = ((link_vrtx_1x - obs_vrtx_1x) * dy2 - (link_vrtx_1y - obs_vrtx_1y) * dx2) / determinant;
                double t2 = ((link_vrtx_1x - obs_vrtx_1x) * dy1 - (link_vrtx_1y - obs_vrtx_1y) * dx1) / determinant;
                cout << "t1: " << t1 <<" t2: " << t2 << std::endl;
                // Check if the line segments intersect within their parameter ranges
                lines_intersect = (t1 >= 0.0 && t1 <= 1.0 && t2 >= 0.0 && t2 <= 1.0);
                cout << "line intesection: " << lines_intersect << std::endl;
                if (lines_intersect)
                {
                    //collision_occurred = true;
                    //cout << "Line Detection Collision!" << std::endl;
                    //cout << "x0: " << x0 << " x1: " << x1 << std::endl;
                    //break;
                    return true;
                }
            }
            // if (lines_intersect)
            // {
            //     break;
            // }
        }
        // if (lines_intersect)
        // {
        //     break;
        // }
    }
    cout << "inCollision return!" << std::endl;
    return false;
};
