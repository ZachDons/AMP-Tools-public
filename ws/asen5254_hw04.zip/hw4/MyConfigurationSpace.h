#pragma once // includes are included only once
#include "AMPCore.h"
#include <cmath>
#include <iostream>
#include "MyLinkManipulator2D.h"
using std::vector, Eigen::Vector2d, std::cout;
using namespace amp;

class MyConfigurationSpace : public amp::GridCSpace2D
{
public:
    MyConfigurationSpace(std::size_t x0_cells, std::size_t x1_cells, double x0_min, double x0_max, double x1_min, double x1_max);
    // compute_Cspace(link_len, ex3_workspace.obstacles)
    // config_space.compute_Cspace(link_len, ex3_workspace.obstacles)
    // void compute_Cspace(std::vector<Eigen::Vector2d> obstacle_vertices, const amp::LinkManipulator2D &robot);
    void compute_Cspace(vector<amp::Obstacle2D> obstacles, MyLinkManipulator2D robot);
    //bool MyConfigurationSpace::check_collision(double x0, double x1);

    virtual bool inCollision(double x0, double x1) const override;

private:
    // member variables
    vector<Obstacle2D> all_obstacles;
    MyLinkManipulator2D my_robot;
};